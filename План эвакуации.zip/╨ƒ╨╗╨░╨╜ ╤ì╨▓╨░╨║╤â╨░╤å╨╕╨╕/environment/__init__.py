from .maze import Maze
from .maze import Status
